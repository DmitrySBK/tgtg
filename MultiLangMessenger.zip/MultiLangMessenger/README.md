# Twitter to Telegram Bot

This bot monitors specified Twitter accounts, translates new tweets to Russian, and posts them to a Telegram channel.

## Features

- Monitor multiple Twitter accounts for new tweets
- Translate tweets to Russian (or another target language)
- Post original and translated tweets to a Telegram channel
- Handle rate limiting and errors gracefully
- Detailed logging for monitoring and debugging

## Requirements

- Python 3.6+
- tweepy (Twitter API client)
- python-telegram-bot (Telegram Bot API)
- deep-translator (for translation services)

## Configuration

Create a `.env` file based on the provided `.env.example`:

