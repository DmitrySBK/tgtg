from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class TwitterAccount(db.Model):
    """Twitter account being monitored"""
    __tablename__ = 'twitter_accounts'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(255), unique=True, nullable=False)
    twitter_id = db.Column(db.BigInteger, nullable=True)  # User ID from Twitter API
    last_tweet_id = db.Column(db.BigInteger, nullable=True)  # Last processed tweet ID
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship with tweets
    tweets = db.relationship('Tweet', backref='account', lazy=True, cascade="all, delete-orphan")
    
    def __repr__(self):
        return f'<TwitterAccount @{self.username}>'

class Tweet(db.Model):
    """Tweet that was processed and sent to Telegram"""
    __tablename__ = 'tweets'
    
    id = db.Column(db.Integer, primary_key=True)
    tweet_id = db.Column(db.BigInteger, nullable=False, unique=True)
    account_id = db.Column(db.Integer, db.ForeignKey('twitter_accounts.id'), nullable=False)
    content = db.Column(db.Text, nullable=False)
    translated_content = db.Column(db.Text, nullable=False)
    sent_to_telegram = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<Tweet {self.tweet_id}>'

class BotStatus(db.Model):
    """Singleton model to track bot status"""
    __tablename__ = 'bot_status'
    
    id = db.Column(db.Integer, primary_key=True)
    is_running = db.Column(db.Boolean, default=False)
    tweets_sent = db.Column(db.Integer, default=0)
    last_check_time = db.Column(db.DateTime, nullable=True)
    last_error = db.Column(db.Text, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def get_status(cls):
        """Get or create the singleton bot status record"""
        status = cls.query.first()
        if not status:
            status = cls()
            db.session.add(status)
            db.session.commit()
        return status
    
    def increment_tweets_sent(self, count=1):
        """Increment the tweets_sent counter"""
        self.tweets_sent += count
        self.updated_at = datetime.utcnow()
        db.session.commit()
    
    def update_check_time(self):
        """Update the last check time"""
        self.last_check_time = datetime.utcnow()
        self.updated_at = datetime.utcnow()
        db.session.commit()
        
    def log_error(self, error_text):
        """Log the last error"""
        self.last_error = error_text
        self.updated_at = datetime.utcnow()
        db.session.commit()
    
    def __repr__(self):
        return f'<BotStatus running={self.is_running} tweets={self.tweets_sent}>'