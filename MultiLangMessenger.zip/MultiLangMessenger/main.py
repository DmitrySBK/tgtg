import os
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
import threading
import time
import logging
import json
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "default_secret_key")

# Configure the database
app.config["SQLALCHEMY_DATABASE_URI"] = os.environ.get("DATABASE_URL")
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize the database
from models import db, BotStatus, TwitterAccount, Tweet
db.init_app(app)

# Create database tables
with app.app_context():
    db.create_all()

# Global variables to track bot thread
bot_thread = None
bot_running = False

# Initialize bot status from database
with app.app_context():
    bot_status = BotStatus.get_status().__dict__
    # Remove SQLAlchemy instance state
    if '_sa_instance_state' in bot_status:
        bot_status.pop('_sa_instance_state')
    # Initialize errors list if not present
    if 'errors' not in bot_status or bot_status['errors'] is None:
        bot_status['errors'] = []
    else:
        # Convert stored error string to list
        bot_status['errors'] = [bot_status['errors']]
    
    # Get accounts being monitored
    accounts = TwitterAccount.query.all()
    bot_status['accounts_monitored'] = [account.username for account in accounts]

def update_status(status_update):
    """Update the bot status"""
    global bot_status
    
    # Update in-memory status
    bot_status.update(status_update)
    
    # Keep only the last 10 errors
    if "errors" in bot_status and len(bot_status["errors"]) > 10:
        bot_status["errors"] = bot_status["errors"][-10:]
    
    # Update database status
    with app.app_context():
        db_status = BotStatus.get_status()
        
        if "last_check_time" in status_update:
            db_status.last_check_time = datetime.strptime(
                status_update["last_check_time"], 
                '%Y-%m-%d %H:%M:%S'
            )
        
        if "tweets_sent" in status_update:
            db_status.tweets_sent = status_update["tweets_sent"]
        
        if "errors" in status_update and status_update["errors"]:
            # Store the most recent error
            db_status.last_error = status_update["errors"][-1]
        
        # Update is_running flag
        db_status.is_running = bot_running
        
        db.session.commit()

def bot_worker():
    """Function to run the bot in a separate thread"""
    global bot_running
    try:
        # Import the bot module here to avoid circular imports
        from bot import main as run_bot
        
        # Set up a custom handler to capture bot logs
        class StatusHandler(logging.Handler):
            def emit(self, record):
                if record.levelno >= logging.ERROR:
                    error_msg = f"{record.asctime} - {record.levelname}: {record.getMessage()}"
                    update_status({"errors": bot_status["errors"] + [error_msg]})
        
        # Add the custom handler to the logger
        bot_logger = logging.getLogger("bot")
        status_handler = StatusHandler()
        bot_logger.addHandler(status_handler)
        
        # Start the bot
        bot_running = True
        update_status({"last_check_time": datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
        run_bot()  # This will run until stopped
    except Exception as e:
        logger.error(f"Bot thread error: {e}")
        update_status({"errors": bot_status["errors"] + [f"Bot thread error: {str(e)}"]})
    finally:
        bot_running = False

@app.route('/')
def index():
    """Main page - show bot status and controls"""
    # Read config values from environment
    from config import (
        TWITTER_BEARER_TOKEN, TELEGRAM_BOT_TOKEN, TELEGRAM_CHANNEL_ID,
        TWITTER_ACCOUNTS, REQUEST_DELAY, MAX_RESULTS,
        SOURCE_LANGUAGE, TARGET_LANGUAGE
    )
    
    config = {
        "twitter_token_set": bool(TWITTER_BEARER_TOKEN),
        "telegram_token_set": bool(TELEGRAM_BOT_TOKEN),
        "telegram_channel_set": bool(TELEGRAM_CHANNEL_ID),
        "twitter_accounts": TWITTER_ACCOUNTS,
        "request_delay": REQUEST_DELAY,
        "max_results": MAX_RESULTS,
        "source_language": SOURCE_LANGUAGE,
        "target_language": TARGET_LANGUAGE
    }
    
    return render_template(
        'index.html', 
        bot_running=bot_running, 
        bot_status=bot_status,
        config=config
    )

@app.route('/start', methods=['POST'])
def start_bot():
    """Start the bot"""
    global bot_thread, bot_running
    
    if bot_running:
        flash('Bot is already running!', 'warning')
        return redirect(url_for('index'))
    
    # Check configuration before starting
    from config import validate_config
    if not validate_config():
        flash('Invalid configuration. Please check your environment variables.', 'danger')
        return redirect(url_for('index'))
    
    # Start the bot in a separate thread
    bot_thread = threading.Thread(target=bot_worker, daemon=True)
    bot_thread.start()
    
    flash('Bot started successfully!', 'success')
    return redirect(url_for('index'))

@app.route('/stop', methods=['POST'])
def stop_bot():
    """Stop the bot (this is just a signal, actual stopping happens in the bot thread)"""
    global bot_running
    
    if not bot_running:
        flash('Bot is not running!', 'warning')
        return redirect(url_for('index'))
    
    # Set flag to stop the bot
    bot_running = False
    flash('Bot stop signal sent. The bot will stop after current operation completes.', 'info')
    return redirect(url_for('index'))

@app.route('/status', methods=['GET'])
def get_status():
    """Return the current bot status as JSON (for AJAX updates)"""
    return jsonify({
        "running": bot_running,
        "status": bot_status
    })

# Create templates directory and templates if they don't exist
os.makedirs('templates', exist_ok=True)

if not os.path.exists('templates/index.html'):
    with open('templates/index.html', 'w') as f:
        f.write('''<!DOCTYPE html>
<html data-bs-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Twitter to Telegram Bot</title>
    <link rel="stylesheet" href="https://cdn.replit.com/agent/bootstrap-agent-dark-theme.min.css">
    <style>
        .status-card {
            transition: all 0.3s ease;
        }
        .error-log {
            max-height: 300px;
            overflow-y: auto;
        }
    </style>
</head>
<body>
    <div class="container py-4">
        <div class="row mb-4">
            <div class="col">
                <h1 class="display-5">Twitter to Telegram Bot</h1>
                <p class="lead">Monitor Twitter accounts, translate tweets, and post to Telegram</p>
            </div>
        </div>

        {% with messages = get_flashed_messages(with_categories=true) %}
            {% if messages %}
                {% for category, message in messages %}
                    <div class="alert alert-{{ category }} alert-dismissible fade show" role="alert">
                        {{ message }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                {% endfor %}
            {% endif %}
        {% endwith %}

        <!-- Configuration Status -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Configuration Status</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Twitter API Token
                                {% if config.twitter_token_set %}
                                    <span class="badge bg-success">Set</span>
                                {% else %}
                                    <span class="badge bg-danger">Missing</span>
                                {% endif %}
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Telegram Bot Token
                                {% if config.telegram_token_set %}
                                    <span class="badge bg-success">Set</span>
                                {% else %}
                                    <span class="badge bg-danger">Missing</span>
                                {% endif %}
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Telegram Channel ID
                                {% if config.telegram_channel_set %}
                                    <span class="badge bg-success">Set</span>
                                {% else %}
                                    <span class="badge bg-danger">Missing</span>
                                {% endif %}
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <div class="card h-100">
                            <div class="card-header">Twitter Accounts</div>
                            <div class="card-body">
                                {% if config.twitter_accounts %}
                                    <ul class="list-group">
                                        {% for account in config.twitter_accounts %}
                                            <li class="list-group-item">@{{ account }}</li>
                                        {% endfor %}
                                    </ul>
                                {% else %}
                                    <p class="text-danger">No Twitter accounts configured</p>
                                {% endif %}
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row mt-3">
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-header">Bot Settings</div>
                            <div class="card-body">
                                <ul class="list-group">
                                    <li class="list-group-item d-flex justify-content-between">
                                        Check Interval: <span>{{ config.request_delay }} seconds</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between">
                                        Max Tweets Per Check: <span>{{ config.max_results }}</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between">
                                        Translation: <span>{{ config.source_language }} → {{ config.target_language }}</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Bot Control -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Bot Control</h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5>Bot Status: 
                            {% if bot_running %}
                                <span class="badge bg-success">Running</span>
                            {% else %}
                                <span class="badge bg-secondary">Stopped</span>
                            {% endif %}
                        </h5>
                    </div>
                    <div>
                        {% if bot_running %}
                            <form action="/stop" method="post" class="d-inline">
                                <button type="submit" class="btn btn-danger">Stop Bot</button>
                            </form>
                        {% else %}
                            <form action="/start" method="post" class="d-inline">
                                <button type="submit" class="btn btn-primary">Start Bot</button>
                            </form>
                        {% endif %}
                    </div>
                </div>
            </div>
        </div>

        <!-- Bot Status -->
        <div class="card mb-4 status-card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Bot Status</h5>
                <button id="refreshStatus" class="btn btn-sm btn-secondary">Refresh</button>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <p><strong>Last Check:</strong> <span id="lastCheckTime">{{ bot_status.last_check_time or 'Never' }}</span></p>
                        <p><strong>Accounts Monitored:</strong> <span id="accountsMonitored">{{ bot_status.accounts_monitored|length }}</span></p>
                        <p><strong>Tweets Sent:</strong> <span id="tweetsSent">{{ bot_status.tweets_sent }}</span></p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Error Log -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Error Log</h5>
            </div>
            <div class="card-body">
                <div class="error-log" id="errorLog">
                    {% if bot_status.errors %}
                        {% for error in bot_status.errors %}
                            <div class="alert alert-danger mb-2">{{ error }}</div>
                        {% endfor %}
                    {% else %}
                        <p class="text-muted">No errors recorded</p>
                    {% endif %}
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const refreshButton = document.getElementById('refreshStatus');
            
            // Function to update the status display
            function updateStatus() {
                fetch('/status')
                    .then(response => response.json())
                    .then(data => {
                        // Update status indicators
                        document.getElementById('lastCheckTime').textContent = 
                            data.status.last_check_time || 'Never';
                        document.getElementById('accountsMonitored').textContent = 
                            data.status.accounts_monitored ? data.status.accounts_monitored.length : 0;
                        document.getElementById('tweetsSent').textContent = 
                            data.status.tweets_sent;
                        
                        // Update error log
                        const errorLog = document.getElementById('errorLog');
                        if (data.status.errors && data.status.errors.length > 0) {
                            errorLog.innerHTML = '';
                            data.status.errors.forEach(error => {
                                const errorDiv = document.createElement('div');
                                errorDiv.className = 'alert alert-danger mb-2';
                                errorDiv.textContent = error;
                                errorLog.appendChild(errorDiv);
                            });
                        } else {
                            errorLog.innerHTML = '<p class="text-muted">No errors recorded</p>';
                        }
                        
                        // Flash the status card to indicate an update
                        const statusCard = document.querySelector('.status-card');
                        statusCard.style.backgroundColor = 'rgba(25, 135, 84, 0.1)';
                        setTimeout(() => {
                            statusCard.style.backgroundColor = '';
                        }, 500);
                    })
                    .catch(error => console.error('Error fetching status:', error));
            }
            
            // Set up refresh button
            refreshButton.addEventListener('click', updateStatus);
            
            // Auto-refresh status every 30 seconds
            setInterval(updateStatus, 30000);
        });
    </script>
</body>
</html>''')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)