import os
import logging
from typing import List
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load environment variables from .env file
def load_env_from_file():
    """Load environment variables from .env file"""
    env_path = Path('.') / '.env'
    if env_path.exists():
        logger.info("Loading environment variables from .env file")
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                key, value = line.split('=', 1)
                # Set environment variable if not already set
                if not os.environ.get(key):
                    os.environ[key] = value
                    logger.debug(f"Set environment variable: {key}")

# Load environment variables from file
load_env_from_file()

# Twitter API credentials
TWITTER_BEARER_TOKEN = os.getenv("TWITTER_BEARER_TOKEN", "")

# Telegram credentials
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHANNEL_ID = os.getenv("TELEGRAM_CHANNEL_ID", "")

# Twitter accounts to monitor (comma-separated list in env var)
twitter_accounts_env = os.getenv("TWITTER_ACCOUNTS", "")
logger.info(f"TWITTER_ACCOUNTS environment variable: '{twitter_accounts_env}'")

TWITTER_ACCOUNTS: List[str] = [
    account.strip() for account in twitter_accounts_env.split(",") if account.strip()
] if twitter_accounts_env else []
logger.info(f"Parsed TWITTER_ACCOUNTS: {TWITTER_ACCOUNTS}")

# Operation settings
REQUEST_DELAY = int(os.getenv("REQUEST_DELAY", "300"))  # Default: 5 minutes between requests
MAX_RESULTS = int(os.getenv("MAX_RESULTS", "5"))  # Default: fetch 5 tweets per request
RATE_LIMIT_WAIT = int(os.getenv("RATE_LIMIT_WAIT", "900"))  # Default: wait 15 minutes on rate limit
ERROR_WAIT = int(os.getenv("ERROR_WAIT", "60"))  # Default: wait 60 seconds after other errors

# Translation settings
SOURCE_LANGUAGE = os.getenv("SOURCE_LANGUAGE", "auto")
TARGET_LANGUAGE = os.getenv("TARGET_LANGUAGE", "ru")

# Validate required configuration
def validate_config() -> bool:
    """Validate that all required configuration is present"""
    if not TWITTER_BEARER_TOKEN:
        logger.error("Missing TWITTER_BEARER_TOKEN environment variable")
        return False
    
    if not TELEGRAM_BOT_TOKEN:
        logger.error("Missing TELEGRAM_BOT_TOKEN environment variable")
        return False
    
    if not TELEGRAM_CHANNEL_ID:
        logger.error("Missing TELEGRAM_CHANNEL_ID environment variable")
        return False
    
    if not TWITTER_ACCOUNTS:
        logger.error("No Twitter accounts specified in TWITTER_ACCOUNTS environment variable")
        return False
    
    return True
