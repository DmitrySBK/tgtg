import logging
from datetime import datetime
from typing import Dict, Optional, List, Tuple, Any

import tweepy
from telegram import Bot  # Using Bot from python-telegram-bot v13.7
from deep_translator import GoogleTranslator

import re

from config import (TWITTER_BEARER_TOKEN, TELEGRAM_BOT_TOKEN,
                    TELEGRAM_CHANNEL_ID, SOURCE_LANGUAGE, TARGET_LANGUAGE)

logger = logging.getLogger(__name__)


# Initialize Twitter client
def get_twitter_client() -> tweepy.Client:
    """Initialize and return Twitter API client"""
    return tweepy.Client(bearer_token=TWITTER_BEARER_TOKEN,
                         wait_on_rate_limit=True)


# Cache for Twitter user IDs
user_id_cache: Dict[str, int] = {}


def get_user_id(twitter_client: tweepy.Client, username: str) -> Optional[int]:
    """Get Twitter user ID with caching to reduce API calls"""
    if username in user_id_cache:
        return user_id_cache[username]

    try:
        user = twitter_client.get_user(username=username)
        if user and user.data:
            user_id_cache[username] = user.data.id
            return user.data.id
        else:
            logger.warning(f"Could not find user with username @{username}")
            return None
    except Exception as e:
        logger.error(f"Error getting user ID for @{username}: {e}")
        return None


def translate_text(text: str) -> str:
    """Translate text to Russian using Google Translator"""
    try:
        if SOURCE_LANGUAGE not in ['auto', 'en', 'ru', 'fr',
                                   'de']:  # Add supported codes here
            logger.error(f"Unsupported source language: {SOURCE_LANGUAGE}")
            return f"{text}\n\n[Translation error: Unsupported source language: {SOURCE_LANGUAGE}]"

        # Limit text length to 5000 characters to ensure translation works
        translated = GoogleTranslator(source=SOURCE_LANGUAGE,
                                      target=TARGET_LANGUAGE).translate(
                                          text[:5000])
        return translated or text  # Fall back to original if translation fails
    except Exception as e:
        logger.error(f"Translation error: {e}")
        return f"{text}\n\n[Translation error: {str(e)}]"


def send_to_telegram(message: str,
                     media_urls: Optional[List[str]] = None) -> bool:
    """Send a message to the Telegram channel, optionally with media"""
    try:
        telegram_bot = Bot(token=TELEGRAM_BOT_TOKEN)

        # Удаляем ссылки из текста сообщения
        message = re.sub(r'http\S+|www\S+|https\S+',
                         '',
                         message,
                         flags=re.MULTILINE)
        # Если у нас есть медиа, отправляем как фото или медиа группу
        if media_urls and len(media_urls) > 0:
            if len(media_urls) == 1:
                # Отправляем одно фото с подписью
                telegram_bot.send_photo(chat_id=TELEGRAM_CHANNEL_ID,
                                        photo=media_urls[0],
                                        caption=message,
                                        parse_mode="HTML")
            else:
                # Отправляем несколько фото как медиа группу
                media_urls = media_urls[:10] if len(
                    media_urls) > 10 else media_urls
                media = [{
                    "type": "photo",
                    "media": media_urls[0],
                    "caption": message,
                    "parse_mode": "HTML"
                }]
                for url in media_urls[1:]:
                    media.append({"type": "photo", "media": url})
                telegram_bot.send_media_group(chat_id=TELEGRAM_CHANNEL_ID,
                                              media=media)
        else:
            # Если медиа нет, просто отправляем текстовое сообщение
            telegram_bot.send_message(chat_id=TELEGRAM_CHANNEL_ID,
                                      text=message,
                                      parse_mode="HTML")
        return True
    except Exception as e:
        logger.error(f"Telegram error: {e}")
        return False


def format_tweet_message(account: str, tweet_text: str,
                         translated_text: str) -> str:
    """Format tweet message for Telegram"""
    # Create message with only the translation text - no account name, no timestamp
    message = translated_text

    # Make sure message is not too long for Telegram (4096 char limit)
    if len(message) > 4000:
        message = message[:3950] + "...\n[Сообщение сокращено из-за длины]"

    return message


def fetch_tweets(
        twitter_client: tweepy.Client,
        user_id: int,
        since_id: Optional[int] = None,
        max_results: int = 5) -> Tuple[List[tweepy.Tweet], Optional[Dict]]:
    """Fetch tweets for a specific user"""
    try:
        # Add expansions and media fields to get images
        tweets = twitter_client.get_users_tweets(
            id=user_id,
            max_results=max_results,
            since_id=since_id,
            expansions=["attachments.media_keys"],
            media_fields=["type", "url", "preview_image_url", "media_key"])

        if tweets and tweets.data:
            return tweets.data, tweets.includes if hasattr(
                tweets, 'includes') else None
        return [], None
    except Exception as e:
        logger.error(f"Error fetching tweets: {e}")
        return [], None


def process_tweets(twitter_client: tweepy.Client,
                   account: str,
                   last_tweet_id: Optional[int],
                   db_session=None) -> Tuple[int, int]:
    """Process tweets for an account and return stats"""
    from main import app
    from models import db, TwitterAccount, Tweet

    # Get user ID for the account
    user_id = get_user_id(twitter_client, account)
    if not user_id:
        return 0, 0

    # Fetch new tweets
    tweets, includes = fetch_tweets(twitter_client, user_id, last_tweet_id)
    tweets_sent = 0
    latest_id = last_tweet_id

    # Process media includes if available
    media_by_key = {}
    if includes and 'media' in includes:
        for media in includes['media']:
            media_url = None
            # Get the best quality URL for the media
            if media.get('url'):
                media_url = media['url']
            elif media.get('preview_image_url'):
                media_url = media['preview_image_url']

            if media_url and media.get('media_key'):
                media_by_key[media['media_key']] = media_url

    # Create app context for database operations if no session provided
    if not db_session:
        with app.app_context():
            # Get or create account record
            db_account = TwitterAccount.query.filter_by(
                username=account).first()
            if not db_account:
                db_account = TwitterAccount(username=account,
                                            twitter_id=user_id)
                db.session.add(db_account)
                db.session.commit()

            # Process tweets
            for tweet in tweets:
                # Check if we've already processed this tweet
                existing = Tweet.query.filter_by(tweet_id=tweet.id).first()
                if existing:
                    logger.info(
                        f"Tweet {tweet.id} already processed, skipping")
                    continue

                translated = translate_text(tweet.text)
                message = format_tweet_message(account, tweet.text, translated)

                # Create tweet record
                db_tweet = Tweet(tweet_id=tweet.id,
                                 account_id=db_account.id,
                                 content=tweet.text,
                                 translated_content=translated)

                # Extract media URLs for this tweet
                media_urls = []
                if hasattr(
                        tweet, 'attachments'
                ) and tweet.attachments and 'media_keys' in tweet.attachments:
                    for media_key in tweet.attachments['media_keys']:
                        if media_key in media_by_key:
                            media_urls.append(media_by_key[media_key])

                # Send to Telegram with media if available
                if send_to_telegram(message,
                                    media_urls if media_urls else None):
                    db_tweet.sent_to_telegram = True
                    tweets_sent += 1
                    # Update latest tweet ID
                    if not latest_id or tweet.id > latest_id:
                        latest_id = tweet.id

                db.session.add(db_tweet)

            # Update account with latest tweet ID
            if latest_id and latest_id != last_tweet_id:
                db_account.last_tweet_id = latest_id

            db.session.commit()
    else:
        # For future implementation with an external session
        logger.info("External session not implemented yet")

    return tweets_sent, latest_id
