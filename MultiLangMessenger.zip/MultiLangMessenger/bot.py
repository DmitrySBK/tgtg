import time
import logging

import tweepy

from config import (
    TWITTER_ACCOUNTS, REQUEST_DELAY, RATE_LIMIT_WAIT, ERROR_WAIT,
    validate_config, logger
)
from utils import (
    get_twitter_client, process_tweets, get_user_id
)

def main():
    """Main entry point for the Twitter to Telegram bot"""
    logger.info("Starting Twitter to Telegram bot...")
    
    # Import needed modules inside function to avoid circular imports
    from main import app
    from models import db, TwitterAccount, BotStatus
    
    # Validate configuration
    if not validate_config():
        logger.error("Invalid configuration. Please check your environment variables.")
        return
    
    # Initialize Twitter API client
    twitter_client = get_twitter_client()
    
    # Update bot status in database
    with app.app_context():
        # Get status object
        bot_status = BotStatus.get_status()
        bot_status.is_running = True
        db.session.commit()
    
    # Validate Twitter accounts and initialize or update database
    valid_accounts = []
    
    with app.app_context():
        # Get existing accounts from database
        existing_accounts = {acc.username: acc for acc in TwitterAccount.query.all()}
        
        # Process accounts from configuration
        for account in TWITTER_ACCOUNTS:
            twitter_id = get_user_id(twitter_client, account)
            if twitter_id:
                valid_accounts.append(account)
                
                # Create or update account in database
                if account in existing_accounts:
                    # Update existing account
                    existing_accounts[account].twitter_id = twitter_id
                else:
                    # Create new account
                    new_account = TwitterAccount(
                        username=account,
                        twitter_id=twitter_id
                    )
                    db.session.add(new_account)
            else:
                logger.warning(f"Skipping invalid account: {account}")
        
        # Commit changes
        db.session.commit()
    
    if not valid_accounts:
        logger.error("No valid Twitter accounts to monitor!")
        with app.app_context():
            bot_status = BotStatus.get_status()
            bot_status.is_running = False
            bot_status.log_error("No valid Twitter accounts to monitor")
            db.session.commit()
        return
    
    logger.info(f"Monitoring {len(valid_accounts)} Twitter accounts: {', '.join(valid_accounts)}")
    
    # Main monitoring loop
    while True:
        try:
            # Check if we should stop (controlled by main app)
            with app.app_context():
                bot_status = BotStatus.get_status()
                if not bot_status.is_running:
                    logger.info("Bot stop signal received")
                    break
                
                # Update check time
                bot_status.update_check_time()
            
            # Process each account
            total_tweets_sent = 0
            
            for account in valid_accounts:
                logger.info(f"Checking tweets for @{account}")
                
                with app.app_context():
                    # Get account from database with last tweet ID
                    db_account = TwitterAccount.query.filter_by(username=account).first()
                    last_tweet_id = db_account.last_tweet_id if db_account else None
                    
                    # Process tweets for this account
                    tweets_sent, latest_id = process_tweets(
                        twitter_client, account, last_tweet_id
                    )
                    
                    # Update total count
                    total_tweets_sent += tweets_sent
                    
                    # Update bot status with new tweet count
                    if tweets_sent > 0:
                        bot_status = BotStatus.get_status()
                        bot_status.increment_tweets_sent(tweets_sent)
                
                if tweets_sent > 0:
                    logger.info(f"Sent {tweets_sent} new tweets from @{account}")
                else:
                    logger.info(f"No new tweets from @{account}")
                
                # Wait between accounts to avoid hitting rate limits
                logger.debug(f"Waiting {REQUEST_DELAY} seconds before next account check")
                time.sleep(REQUEST_DELAY)
                
        except tweepy.TooManyRequests:
            logger.warning(f"Rate limited by Twitter API. Waiting {RATE_LIMIT_WAIT//60} minutes...")
            time.sleep(RATE_LIMIT_WAIT)
            
        except KeyboardInterrupt:
            logger.info("Bot stopped by user.")
            break
            
        except Exception as e:
            logger.error(f"Unexpected error: {e}", exc_info=True)
            logger.info(f"Waiting {ERROR_WAIT} seconds before retrying...")
            time.sleep(ERROR_WAIT)

if __name__ == "__main__":
    main()
